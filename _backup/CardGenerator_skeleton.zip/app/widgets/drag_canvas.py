# drag canvas stub
