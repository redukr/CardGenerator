# image loader stub
